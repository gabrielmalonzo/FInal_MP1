import React, { useState } from 'react';
import { View, TextInput, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';

const App = () => {
  const [temperature, setTemperature] = useState('');
  const [scale, setScale] = useState('F');
  const [backgroundColor, setBackgroundColor] = useState('#FFF2D7'); // Default background color

  const handleTemperatureChange = (text) => {
    setTemperature(text);
    if (scale === 'F') {
      // Change background color based on Fahrenheit temperature
      setBackgroundColor(text >= 32 ? '#FF6347' : '#87CEEB');
    } else {
      // Change background color based on Celsius temperature
      setBackgroundColor(text >= 0 ? '#87CEEB' : '#FF6347');
    }
  };

  const convertTemperature = () => {
    if (scale === 'F') {
      return (parseFloat(temperature) * 9) / 5 + 32; // Convert Celsius to Fahrenheit
    } else {
      return ((parseFloat(temperature) - 32) * 5) / 9; // Convert Fahrenheit to Celsius
    }
  };

  const handleSwitchScale = () => {
    setScale(scale === 'F' ? 'C' : 'F');
  };

  return (
    <View style={[styles.container, { backgroundColor }]}>
      {backgroundColor === '#FF6347' && <Image source={require('./assets/Sun.png')} style={styles.image} />}
      {backgroundColor === '#87CEEB' && <Image source={require('./assets/Snowflakes.png')} style={styles.image} />}
      <Text style={styles.title}>Temperature Converter</Text>
      <TextInput
        style={styles.input}
        onChangeText={handleTemperatureChange}
        value={temperature}
        keyboardType="numeric"
        placeholder="Enter temperature"
      />
      <Text style={[styles.result, { fontWeight: 'bold' }]}>
        {scale === 'F' ? 'Fahrenheit: ' : 'Celsius: '}
        {convertTemperature().toFixed(2)}°{scale}
      </Text>
      <TouchableOpacity onPress={handleSwitchScale} style={styles.button}>
        <Text style={styles.buttonText}>Switch to {scale === 'F' ? 'Celsius' : 'Fahrenheit'}</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 30,
    paddingHorizontal: 10,
    marginBottom: 10,
  },
  result: {
    fontSize: 20,
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#151515',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 30,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  image: {
    position: 'absolute',
    top: 20,
    alignSelf: 'center',
    width: 130,
    height: 130,
  },
});

export default App;